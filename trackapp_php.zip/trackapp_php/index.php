<?php
    header('Access-Control-Allow-Origin: http://localhost');
	
	require_once('config.php');
	
	if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'register'){ //registeration process
		$username = $_REQUEST['username'];
		$email = $_REQUEST['email'];
		$password = $_REQUEST['password'];
		$type = $_REQUEST['type'];
		
		if($username == "" || $email == "" || $password == "" || $type == ""){
			$array = array(
				'error' => 'true',
				'message' => 'All the fields are mandatory.'
			);
			header( "Content-Type: application/json" );
			echo json_encode($array);
			die();
		}
		
		$count = is_email_exixts($email);
		if($count >= 1){
			$array = array(
				'error' => 'true',
				'message' => 'Email already exists.'
			);
			header( "Content-Type: application/json" );
			echo json_encode($array);
			die();
		}
		
		$date = date("F j, Y");
		$current_date = strtotime($date);
		
		$tocken = $email."kreative".$current_date;
		$tocken = md5($tocken);
		
		$link = $site_url."verify/".$tocken;
		
		//Create a new PHPMailer instance
		$mail = new PHPMailer;
		//Set who the message is to be sent from
		$mail->setFrom($admin_email, $site_title);
		//Set an alternative reply-to address
		$mail->addReplyTo($admin_email, $site_title);
		//Set who the message is to be sent to
		$mail->addAddress($email, $username);
		//Set the subject line
		$mail->Subject = $site_title.' email verification link';
		//Replace the plain text body with one created manually
		$mail->Body = "Dear ".$username."\r\n"."You are successfully registered at ".$site_title.". But your account is not activated yet. To activate your account just click the link given below or copy and paste this link in your browsers address bar."."\r\n".$link."\r\n"."\r\n"."Thanks,"."\r\n"."Regards: "."\r\n".$site_title." Team";

		//send the message, check for errors
		if (!$mail->send()) {
		//if(1 == 2){
			$array = array(
				'error' => 'true',
				'message' => $mail->ErrorInfo
			);
			header( "Content-Type: application/json" );
			echo json_encode($array);
			die();
		} else {
			/*** INSERT data ***/
			$query = $dbh->prepare("INSERT INTO register(username, email, password, tocken, status) VALUES ('$username', '$email', '$password', '$tocken', 'registered')");
			$query->execute();
			$count = $query->rowCount();
			if(!$count)
			{
				$array = array(
					'error' => 'true',
					'message' => $dbh->errorInfo()
				);
				header( "Content-Type: application/json" );
				echo json_encode($array);
				die();
			}
			else{
				$array = array(
					'success' => 'true',
					'message' => 'Please check your mailbox and varfiy your email address.'
				);
				header( "Content-Type: application/json" );
				echo json_encode($array);
				die();
			}
		}
	}
?>