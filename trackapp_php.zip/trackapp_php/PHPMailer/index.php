<?php require_once('../config.php'); ?>
<html>
	<head>
		<title></title>
	</head>
	<body>
		<script>window.location = "<?php echo $site_url; ?>";</script>
	</body>
</html>