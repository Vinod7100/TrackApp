<?php
function is_email_exixts($email){
		global $dbh;
		
		$count = $dbh->prepare("SELECT * FROM register WHERE email = '$email'");
		$count->execute();
		
		$count = $count->rowCount();
		return $count;
	}
	
	
?>